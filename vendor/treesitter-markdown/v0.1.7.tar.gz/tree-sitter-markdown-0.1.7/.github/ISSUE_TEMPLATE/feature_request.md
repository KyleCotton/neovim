---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

<!-- consider linking a relevant section from a spec -->
<!-- extensions from any spec (rmarkdown, pandoc, ...) are welcome -->
