These small grammars demonstrate specific features or test for certain specific regressions.

For some of them, compilation is expected to fail with a given error message. For others, the resulting parser is expected to produce certain trees.