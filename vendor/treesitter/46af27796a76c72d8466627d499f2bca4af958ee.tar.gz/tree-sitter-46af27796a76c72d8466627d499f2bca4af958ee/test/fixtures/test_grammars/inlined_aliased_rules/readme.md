This grammar shows that a rule marked as `inline` can *contain* a `ALIAS` rule.
