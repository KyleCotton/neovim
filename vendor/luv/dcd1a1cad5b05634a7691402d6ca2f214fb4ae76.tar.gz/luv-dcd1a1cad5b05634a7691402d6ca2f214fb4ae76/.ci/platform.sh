if [ "$RUNNER_OS" == "macOS" ]; then
  PLATFORM="macosx";
fi

if [ "$RUNNER_OS" == "Linux" ]; then
  PLATFORM="linux";
fi
