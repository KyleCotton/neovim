#!/usr/bin/env lua

return 42
